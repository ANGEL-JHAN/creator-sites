import { motion } from "framer-motion";
import { ExternalLink } from "lucide-react";
import project1 from "@/assets/project-1.jpg";
import project2 from "@/assets/project-2.jpg";
import project3 from "@/assets/project-3.jpg";
import project4 from "@/assets/project-4.jpg";
import project5 from "@/assets/project-5.jpg";
import project6 from "@/assets/project-6.jpg";

const projects = [
  { title: "TechVentures Corp", category: "Sitio Corporativo", image: project1 },
  { title: "StyleHub Store", category: "E-Commerce", image: project2 },
  { title: "FitLife App", category: "Aplicación Web", image: project3 },
  { title: "GourmetChef", category: "Landing Page", image: project4 },
  { title: "EduConnect", category: "Plataforma Educativa", image: project5 },
  { title: "CryptoTrack", category: "Dashboard", image: project6 },
];

const PortfolioSection = () => {
  return (
    <section id="portfolio" className="py-28 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary text-sm font-medium tracking-widest uppercase">Portafolio</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3">
            Proyectos <span className="text-gradient">destacados</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Cada proyecto es una historia de innovación y excelencia.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="group card-elevated rounded-xl overflow-hidden cursor-pointer hover:border-primary/30 transition-all duration-300"
            >
              <div className="h-48 overflow-hidden relative">
                <img
                  src={project.image}
                  alt={project.title}
                  loading="lazy"
                  width={800}
                  height={600}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-background/0 group-hover:bg-background/20 transition-colors flex items-center justify-center">
                  <ExternalLink size={20} className="text-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <div className="p-5">
                <span className="text-xs text-primary font-medium">{project.category}</span>
                <h3 className="font-display text-base font-semibold mt-1">{project.title}</h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
