import { motion } from "framer-motion";
import { Award, Users, Rocket, Heart } from "lucide-react";
import angelImg from "@/assets/angel-ofc.jpg";

const values = [
  { icon: Award, title: "Calidad Premium", desc: "Cada línea de código está pensada para durar." },
  { icon: Users, title: "Centrado en el Cliente", desc: "Tu visión es nuestra prioridad absoluta." },
  { icon: Rocket, title: "Innovación Constante", desc: "Usamos las últimas tecnologías del mercado." },
  { icon: Heart, title: "Pasión por el Código", desc: "Amamos lo que hacemos y se nota en cada proyecto." },
];

const AboutSection = () => {
  return (
    <section id="about" className="py-28 relative">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary text-sm font-medium tracking-widest uppercase">Sobre Nosotros</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold mt-3 leading-tight">
              Creado por{" "}
              <span className="text-gradient">ANGEL OFC</span>
            </h2>
            <p className="text-muted-foreground mt-6 leading-relaxed">
              Soy ANGEL OFC, fundador de Create Sites. Con años de experiencia en desarrollo web, 
              he construido esta empresa con una misión clara: crear sitios web que no solo se vean 
              increíbles, sino que generen resultados reales para nuestros clientes.
            </p>
            <p className="text-muted-foreground mt-4 leading-relaxed">
              Cada proyecto que tomamos es tratado con la misma dedicación y excelencia. 
              Desde startups hasta empresas consolidadas, nuestro compromiso es entregar 
              soluciones digitales que superen las expectativas.
            </p>

            <div className="mt-8 flex items-center gap-4">
              <img
                src={angelImg}
                alt="ANGEL OFC"
                loading="lazy"
                width={56}
                height={56}
                className="w-14 h-14 rounded-full object-cover ring-2 ring-primary/30"
              />
              <div>
                <div className="font-display font-semibold">ANGEL OFC</div>
                <div className="text-sm text-muted-foreground">Fundador & Lead Developer</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="grid grid-cols-2 gap-4"
          >
            {values.map((v, i) => (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="card-elevated rounded-xl p-5"
              >
                <v.icon size={20} className="text-primary mb-3" />
                <h4 className="font-display text-sm font-semibold">{v.title}</h4>
                <p className="text-xs text-muted-foreground mt-1">{v.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
