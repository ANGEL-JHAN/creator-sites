const Footer = () => {
  return (
    <footer className="border-t border-border py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 items-center">
          <div>
            <span className="font-display text-lg font-bold">
              <span className="text-gradient">Create</span> Sites
            </span>
            <p className="text-xs text-muted-foreground mt-2">
              Desarrollo web profesional por ANGEL OFC
            </p>
          </div>

          <div className="flex justify-center gap-8 text-sm text-muted-foreground">
            <a href="#services" className="hover:text-primary transition-colors">Servicios</a>
            <a href="#portfolio" className="hover:text-primary transition-colors">Portafolio</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contacto</a>
          </div>

          <div className="text-right">
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} Create Sites. Todos los derechos reservados.
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Creado por <span className="text-primary font-medium">ANGEL OFC</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
