import { motion } from "framer-motion";
import { Globe, Smartphone, ShoppingCart, Search, Palette, Zap } from "lucide-react";

const services = [
  {
    icon: Globe,
    title: "Páginas Web",
    description: "Sitios corporativos, landing pages y portafolios con diseño único y rendimiento óptimo.",
  },
  {
    icon: ShoppingCart,
    title: "E-Commerce",
    description: "Tiendas online completas con pasarelas de pago, inventario y panel de administración.",
  },
  {
    icon: Smartphone,
    title: "Apps Web",
    description: "Aplicaciones web progresivas (PWA) con funcionalidad avanzada y experiencia nativa.",
  },
  {
    icon: Search,
    title: "SEO & Marketing",
    description: "Posicionamiento orgánico, optimización de velocidad y estrategias de conversión.",
  },
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Interfaces intuitivas con investigación de usuario, wireframes y prototipos interactivos.",
  },
  {
    icon: Zap,
    title: "Mantenimiento",
    description: "Soporte continuo, actualizaciones de seguridad y monitoreo de rendimiento 24/7.",
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="py-28 relative">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary text-sm font-medium tracking-widest uppercase">Servicios</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold mt-3">
            Todo lo que <span className="text-gradient">necesitas</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Soluciones digitales completas para llevar tu negocio al siguiente nivel.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card-elevated rounded-xl p-7 group hover:border-primary/30 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                <service.icon size={22} className="text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">{service.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
