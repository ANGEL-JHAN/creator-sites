import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `Eres JHAN IA, el asistente virtual inteligente de Create Sites, una empresa de desarrollo web fundada por ANGEL OFC.

Tu personalidad:
- Eres amigable, profesional y entusiasta
- Respondes siempre en español
- Eres conciso pero informativo
- Usas emojis ocasionalmente para ser más cercano

Información de la empresa:
- Nombre: Create Sites
- Fundador: ANGEL OFC
- Servicios: Diseño web, desarrollo web, e-commerce, apps web (PWA), SEO & marketing digital, UI/UX design, mantenimiento web
- Tecnologías: React, Next.js, TypeScript, Tailwind CSS, Node.js, y más
- Precios orientativos: Landing page desde 299€, sitio corporativo desde 499€, e-commerce desde 899€, app web desde 1499€
- Tiempos: Landing page 1-2 semanas, sitio corporativo 2-3 semanas, e-commerce 4-6 semanas, app web 6-10 semanas
- Contacto: contacto@createsites.dev | +34 612 345 678
- Disponibilidad: 100% remoto, clientes globales
- Soporte: 24/7
- Más de 50 proyectos completados con 99% de satisfacción

Si te preguntan algo que no sabes o que no está relacionado con Create Sites, responde amablemente que puedes ayudar con información sobre los servicios de la empresa.`
          },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Demasiadas solicitudes, intenta de nuevo en unos segundos." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Créditos agotados. Contacta al administrador." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "Error del servidor de IA" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("jhan-ia error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Error desconocido" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
